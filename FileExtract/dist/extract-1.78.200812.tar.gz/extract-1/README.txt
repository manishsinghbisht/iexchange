Extract
--------
activate env_iexchange
pyinstaller --onefile -w 'pre.py'



>>> # python start.py


To use (with caution), simply do::

# python setup.py build
# python setup.py install
# python setup.py sdist
# python setup.py bdist --formats=wininst





	#########################
# python setup_cx_freeze.py build
# python setup_cx_freeze.py bdist_msi